﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using SqlServerHelper;
using DataFrom;
using XMLHelper;

public partial class MainView : System.Web.UI.Page
{
    DataFromXMLAndDB dataFromXMLAndDB;
    List<string> heads = new List<string>();
    DataTable uniteTable;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) {
            dataFromXMLAndDB = new DataFromXMLAndDB(Request.QueryString["username"]);
            heads = dataFromXMLAndDB.GetHeadFromDB();
            heads.AddRange(dataFromXMLAndDB.GetHeadFromXML());
            DataTable DBTable = dataFromXMLAndDB.GetDataFromDB();
            DataTable XMLTable = dataFromXMLAndDB.GetDataFromXML();
            uniteTable = UniteTable(DBTable, XMLTable);
            Session["uniteTable"] = uniteTable;
            MainTable.DataSource = uniteTable;
            MainTable.DataBind();
        }
    }
    protected DataTable UniteTable(DataTable DBTable, DataTable XMLTable)
    {
        DBTable.Merge(XMLTable);
        DBTable.PrimaryKey = null;
        DBTable.Columns.Remove("Id");
        DBTable.Columns.Remove("UserId");
        return DBTable;
    }

    protected void addNewRow_Click(object sender, EventArgs e)
    {
        uniteTable = (DataTable)Session["uniteTable"];
        DataRow newRow = uniteTable.NewRow();
        uniteTable.Rows.Add(newRow);
        MainTable.DataSource = uniteTable;
        MainTable.EditIndex = uniteTable.Rows.Count - 1;
        MainTable.DataBind();
    }
    protected void MainTable_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e){
        MainTable.EditIndex = -1;
    }
    protected void MainTable_RowEditing(object sender, GridViewEditEventArgs e){
        MainTable.EditIndex = e.NewEditIndex;
    }
    protected void MainTable_RowUpdating(object sender, GridViewUpdateEventArgs e){
        GridViewRow updateRow = MainTable.Rows[e.RowIndex];
        if (e.RowIndex != MainTable.Rows.Count-1){
            //DB insert
            dataFromXMLAndDB = new DataFromXMLAndDB(Request.QueryString["username"]);
            DataTable XMLTable = dataFromXMLAndDB.GetDataFromXML();
            string sqlStr = "UPDATE dbo.XMLTest SET name=@name, age=@age WHERE Id=@Id";
            int Id;
            int.TryParse(XMLTable.Rows[e.RowIndex]["Id"].ToString(), out Id);
            string name = ((TextBox)updateRow.Cells[1].Controls[0]).Text;
            string age = ((TextBox)updateRow.Cells[2].Controls[0]).Text;
            SqlParameter[] param = { 
                               new SqlParameter("@Id",Id),
                               new SqlParameter("@name",name),
                               new SqlParameter("@age",age)};
            SQLHelper.ExecuteSql(sqlStr, param);
            //XML insert
            string xmlPath = ConfigurationManager.AppSettings["XMLsFile"] + @"\" + Request.QueryString["username"] + ".xml";
            XMLController xmlController = new XMLController(xmlPath);
            List<string> parameters = new List<string>();
            List<string> nameParams = new List<string>();
            for (int i = 3; i < updateRow.Cells.Count; i++)
            {
                nameParams.Add(MainTable.HeaderRow.Cells[i].Text);
                parameters.Add(((TextBox)updateRow.Cells[i].Controls[0]).Text);
            }
            xmlController.EditNodeValue("Id", Id.ToString(), nameParams, parameters);
        }
        else {
            InsertDBAndXML(updateRow);
        }
        MainTable.EditIndex = -1;
    }
    protected void InsertDBAndXML(GridViewRow updateRow){
        //DB insert
        string sqlStr = "INSERT INTO dbo.XMLTest(UserID,Name,Age) VALUES(@userId,@name,@age)";
        dataFromXMLAndDB = new DataFromXMLAndDB(Request.QueryString["username"]);
        int userId = dataFromXMLAndDB.GetUserId();
        string name = ((TextBox)updateRow.Cells[1].Controls[0]).Text;
        string age = ((TextBox)updateRow.Cells[2].Controls[0]).Text;
        SqlParameter[] param = { 
                               new SqlParameter("@userId",userId),
                               new SqlParameter("@name",name),
                               new SqlParameter("@age",age)};
        SQLHelper.ExecuteSql(sqlStr, param);
        //XML insert;
        string xmlPath = ConfigurationManager.AppSettings["XMLsFile"] + @"\" + Request.QueryString["username"] + ".xml";
        XMLController xmlController = new XMLController(xmlPath);
        int uniqueId = GetUniqueId();
        List<string> parameters = new List<string>();
        List<string> nameParams = new List<string>();
        parameters.Add(uniqueId.ToString());
        nameParams.Add("Id");
        for (int i = 3; i < updateRow.Cells.Count; i++)
        {
            nameParams.Add(MainTable.HeaderRow.Cells[i].Text);
            parameters.Add(((TextBox)updateRow.Cells[i].Controls[0]).Text);
        }
        xmlController.AddNodeValue(nameParams, parameters);
    }
    protected int GetUniqueId() {
        int uniqueId = 0;
        string sqlStr = "SELECT IDENT_CURRENT('XMLTest') AS currentIdentity";
        SqlDataReader uniqueIdReader = SQLHelper.ExecuteReader(sqlStr);
        if (uniqueIdReader.Read())
        {
            string uniqueIdStr = uniqueIdReader["currentIdentity"].ToString();
            int.TryParse(uniqueIdStr, out uniqueId);
        }
        return uniqueId;
    }
    protected void MainTable_RowUpdated(object sender, GridViewUpdatedEventArgs e)
    {
        MainTable.EditIndex = -1;
    }
    protected void MainTable_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        dataFromXMLAndDB = new DataFromXMLAndDB(Request.QueryString["username"]);
        DataTable XMLTable = dataFromXMLAndDB.GetDataFromXML();
        int Id;
        int.TryParse(XMLTable.Rows[e.RowIndex]["Id"].ToString(), out Id);
        //DB delete
        string sqlStr = "DELETE FROM dbo.XMLTest WHERE Id=@id";
        SqlParameter[] param = { 
                               new SqlParameter("@Id",Id)};
        SQLHelper.ExecuteSql(sqlStr, param);
        //XML delete
        string xmlPath = ConfigurationManager.AppSettings["XMLsFile"] + @"\" + Request.QueryString["username"] + ".xml";
        XMLController xmlController = new XMLController(xmlPath);
        xmlController.DeleteNodeValue("Id",Id.ToString());
    }
}