﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using SqlServerHelper;

/// <summary>
/// DataFromXMLAndDB 的摘要说明
/// </summary>
namespace DataFrom {
    public class DataFromXMLAndDB
    {
        public int UserId = 0;
        string Username;
        string XmlPath;
        public DataFromXMLAndDB(string usernamePar)
        {
            Username = usernamePar;
        }
        public int GetUserId()
        {
            if (UserId == 0)
            {
                string sqlStr = "SELECT Id FROM dbo.users WHERE Name=@username";
                SqlParameter[] param = {
                                   new SqlParameter("@username",Username)};
                SqlDataReader userIdReader = SQLHelper.ExecuteReader(sqlStr, param);
                if (userIdReader.Read())
                {
                    string theUserId = userIdReader["Id"].ToString();
                    int.TryParse(theUserId, out UserId);
                }
            }
            return UserId;
        }
        protected string GetXMLPath() {
            if (XmlPath == null){
                XmlPath = ConfigurationManager.AppSettings["XMLsFile"] + @"\" + Username + ".xml";
            }
            return XmlPath;
        }
        public List<string> GetHeadFromDB()
        {
            List<string> heads = new List<string>();
            string sqlStr = "SELECT name FROM syscolumns where id=object_id(N'XMLTest')";
            DataTable headTable = SQLHelper.ExecuteDt(sqlStr);
            foreach (DataRow aRow in headTable.Rows)
            {
                heads.Add(aRow["name"].ToString());
            }
            if (heads.Count == 0)
            {
                //alert;
            }
            return heads;
        }
        public List<string> GetHeadFromXML() {
            List<string> heads = new List<string>();
            string xmlPath = GetXMLPath();
            DataSet xmlSet = new DataSet();
            xmlSet.ReadXml(xmlPath);
            DataTable XMLTable = xmlSet.Tables[0];
            foreach (DataColumn col in XMLTable.Columns) {
                heads.Add(col.ColumnName);
            }
            return heads;
        }
        public DataTable GetDataFromDB()
        {
            int userid = GetUserId();
            string sqlStr = "SELECT * FROM dbo.XMLTest WHERE UserID=" + userid.ToString();
            DataTable DBTable = SQLHelper.ExecuteDt(sqlStr);
            return DBTable;
        }
        public DataTable GetDataFromXML()
        {
            string xmlPath = GetXMLPath();
            DataSet xmlSet = new DataSet();
            xmlSet.ReadXml(xmlPath);
            DataTable XMLTableOrig = xmlSet.Tables[0];  //只有一个table
            DataTable XMLTable = XMLTableOrig.Clone();
            XMLTable.Columns["Id"].DataType = typeof(Int32);
            foreach (DataRow row in XMLTableOrig.Rows)
            {
                XMLTable.ImportRow(row);
            }
            DataColumn[] primaryKeys = new DataColumn[1];
            primaryKeys[0] = XMLTable.Columns["Id"];
            XMLTable.PrimaryKey = primaryKeys;
            return XMLTable;
        }
    }
}
