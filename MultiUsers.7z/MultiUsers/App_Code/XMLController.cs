﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;

/// <summary>
/// XMLController 的摘要说明
/// </summary>
namespace XMLHelper
{
    public class XMLController
    {
        //
        public XmlDocument document;
        //XML文档的根；
        public XmlElement rootElement;
        //构造函数主要用于绑定XML文件
        protected string path;
        public XMLController(string filePath)
        {
            path = filePath;
            document = new XmlDocument();
            document.Load(filePath);    //加异常处理；
            rootElement = document.DocumentElement;
        }

        //添加一行
        public void AddNodeValue(List<string> nameParams, List<string> parameters)
        {
            XmlElement newElement = document.CreateElement("row");
            for (int i = 0; i < nameParams.Count; i++)
            {
                XmlElement node = document.CreateElement(nameParams[i]);
                node.InnerText = parameters[i];
                newElement.AppendChild(node);
            }
            rootElement.AppendChild(newElement);
            document.Save(path);
        }
        //编辑
        public void EditNodeValue(string PK_Name,string PK_Value,List<string> nameParams, List<string> parameters) {
            XmlNodeList children = rootElement.ChildNodes;
            int find = 0;
            foreach (XmlNode child in children)
            {
                XmlNodeList grandChildren = child.ChildNodes;
                foreach (XmlNode grandChild in grandChildren) {
                    if (grandChild.Name.Equals(PK_Name)&&grandChild.InnerText.Equals(PK_Value)) {
                        find = 1;
                        break;
                    }
                }
                if (find == 1) {
                    for (int i = 0; i < nameParams.Count; i++) {
                        foreach (XmlNode grandChild in grandChildren)
                        {
                            if (grandChild.Name.Equals(nameParams[i])){
                                grandChild.InnerText = parameters[i];
                            }
                        }
                    }
                    find = 0;
                    break;
                }
            }
            document.Save(path);
        }
        //删除
        public void DeleteNodeValue(string PK_Name, string PK_Value){
            XmlNodeList children = rootElement.ChildNodes;
            int find = 0;
            XmlNode deleteingNode = null;
            foreach (XmlNode child in children)
            {
                XmlNodeList grandChildren = child.ChildNodes;
                foreach (XmlNode grandChild in grandChildren)
                {
                    if (grandChild.Name.Equals(PK_Name) && grandChild.InnerText.Equals(PK_Value))
                    {
                        find = 1;
                        break;
                    }
                }
                if (find == 1)
                {
                    deleteingNode = child;
                    break;
                }
            }
            rootElement.RemoveChild(deleteingNode);
            document.Save(path);
        }
    }
}